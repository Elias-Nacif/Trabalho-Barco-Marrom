/**
  ******************************************************************************
  * @file           : magnetometro.c
  * @brief          : Implementação das funções para interface e manipulação do
  *                   sensor magnético HMC5883L com a placa STM32.
  *
  *                   Este arquivo contém funções para inicializar, configurar,
  *                   ler e processar os dados do campo magnético capturados pelo
  *                   sensor HMC5883L. As principais funcionalidades incluem:
  *                     - Configuração dos registradores do HMC5883L.
  *                     - Leitura dos dados brutos do campo magnético.
  *                     - Processamento dos dados, incluindo filtragem, cálculo de
  *                       distância e médias.
  *                     - Conversão de coordenadas para ângulos e cálculo do
  *                       ângulo do leme baseado no ângulo do barco e o ângulo
  *                       de chegada.
  *
  * @authors        : Elias Nacif, Everson Elias, Vincent
  * @date           : 4 de Dezembro de 2024
  * @version        : 2.0
  *
  * @hardware       : STM32 Nucleo F446RE
  *                   Sensor magnético HMC5883L
  *
  * @dependencies   : HAL (Hardware Abstraction Layer) para comunicação I2C.
  *                   Bibliotecas padrão do C para cálculos matemáticos.
  *
  * @details        : Este código foi projetado para integrar um sensor magnético
  *                   HMC5883L em aplicações embarcadas para um trabalho prático
  *                   da matéria de Programação de Sistemas Embarcados (Competição de
  *                   Barcos). Algumas características específicas incluem:
  *                     - Cálculo de um ângulo corrigido para o Norte Magnético.
  *                     - Ajuste da calibração baseado em um desvio fixo.
  *                     - Cálculo do deslocamento angular do leme.
  *
  * @note           : Calibrações (como o desvio de 75°) foram determinadas por
  *                   comparação experimental com uma bússola no celular e portanto não
  *                   são generalizadas.
  *
  ******************************************************************************
  */

#include <math.h>
#include "main.h"
#include "magnetometro.h"
//#include "print_readings.h"
#include <stdio.h>

/******************************************************************************
 * DEFINIÇÕES DE ENDEREÇOS E REGISTRADORES DO HMC5883L
 *****************************************************************************/

#define HMC5883L_ADDRESS          0x1E << 1 // Endereço I2C do HMC5883L

// Registradores do HMC5883L

#define REG_CONFIG_A              0x00
#define REG_CONFIG_B              0x01
#define REG_MODE                  0x02
#define REG_DATA_OUT_X_MSB        0x03
#define REG_DATA_OUT_X_LSB        0x04
#define REG_DATA_OUT_Z_MSB        0x05
#define REG_DATA_OUT_Z_LSB        0x06
#define REG_DATA_OUT_Y_MSB        0x07
#define REG_DATA_OUT_Y_LSB        0x08
#define REG_STATUS                0x09
#define REG_IDENT_A               0x0A
#define REG_IDENT_B               0x0B
#define REG_IDENT_C               0x0C

/******************************************************************************
 * CONFIGURAÇÕES E CONSTANTES
 *****************************************************************************/

// Configuration Register A (CRA)
#define HMC5883L_CRA_SA_POS       6 // Posição dos bits de MÉDIA DE AMOSTRAS no CRA
#define HMC5883L_CRA_SA_TAM       2 // TAMANHO em bits
#define HMC5883L_CRA_DATARATE_POS 4 // Posição dos bits de TAXA DE DADOS no CRA
#define HMC5883L_CRA_DATARATE_TAM 3 // TAMANHO em bits
#define HMC5883L_CRA_MM_POS       1 // Posição do MODO DE MEDIÇÃO no CRA
#define HMC5883L_CRA_MM_TAM       2 // TAMANHO em bits

// Média de Amostras
#define HMC5883L_SAMPLE_AVERAGE_1 0x00 //(Padrão)
#define HMC5883L_SAMPLE_AVERAGE_2 0x01
#define HMC5883L_SAMPLE_AVERAGE_4 0x02
#define HMC5883L_SAMPLE_AVERAGE_8 0x03

// Taxa de Saída de Dados Típica (Hz)
#define HMC5883L_DATARATE_0_75_HZ 0x00
#define HMC5883L_DATARATE_1_5HZ   0x01
#define HMC5883L_DATARATE_3HZ     0x02
#define HMC5883L_DATARATE_7_5HZ   0x03
#define HMC5883L_DATARATE_15HZ    0x04 //(Padrão)
#define HMC5883L_DATARATE_30HZ    0x05
#define HMC5883L_DATARATE_75HZ    0x06

// Modo de Medição
#define HMC5883L_MEAS_MODE_NORMAL 0x00 //(Padrão)
#define HMC5883L_MEAS_MODE_POS    0x01
#define HMC5883L_MEAS_MODE_NEG    0x02


// Registrador de Configuração B
// Layout dos bits do Registrador de Configuração B (CRB)
#define HMC5883L_CRB_RANGE_POS    7 // Posição dos bits de ALCANCE no CRB
#define HMC5883L_CRB_RANGE_TAM    3 // TAMANHO em bits

// ALCANCE -> GANHO
#define HMC5883L_RANGE_0_88GA     0x00
#define HMC5883L_RANGE_1_3GA	  0x01 //(Padrão)
#define HMC5883L_RANGE_1_9GA	  0x02
#define HMC5883L_RANGE_2_5GA      0x03
#define HMC5883L_RANGE_4GA        0x04
#define HMC5883L_RANGE_4_7GA      0x05
#define HMC5883L_RANGE_5_7GA      0x06
#define HMC5883L_RANGE_8_1GA      0x07

// Registrador de Modo
// Layout dos bits do Registrador de Modo
#define HMC5883L_MODEREG_POS      1 // Posição do MODO no Registrador de Modo
#define HMC5883L_MODEREG_TAM      2 // TAMANHO em bits

#define HMC5883L_MODE_CONTINUOUS    0x00 // Modo contínuo
#define HMC5883L_MODE_SINGLE        0x01 // Modo de medição única
#define HMC5883L_MODE_IDLE          0x02 // Modo inativo
uint8_t mode = HMC5883L_MODE_CONTINUOUS;                                  // Modo contínuo


/******************************************************************************
 * FUNÇÕES DE INICIALIZAÇÃO E CONFIGURAÇÃO
 *****************************************************************************/

/**
  * @brief  Initializa e Configura o HMC5883L para seu funcionamento desejado
  * @param  hi2c Ponteiro para uma estrutura I2C_HandleTypeDef que contém
  *         as informações de configuração do I2C especificado.
  * @retval None
  */
void HMC5883L_Init(I2C_HandleTypeDef *hi2c){
	uint8_t configA = (HMC5883L_SAMPLE_AVERAGE_8 << HMC5883L_CRA_SA_POS) |   // 8 amostras por leitura
	                      (HMC5883L_DATARATE_15HZ << HMC5883L_CRA_DATARATE_POS) | // Taxa de 15Hz
	                      (HMC5883L_MEAS_MODE_NORMAL << HMC5883L_CRA_MM_POS);     // Modo de medição normal
	uint8_t configB = (HMC5883L_RANGE_1_3GA << HMC5883L_CRB_RANGE_POS);       // Ganho de ±1.3 Gauss



    // Configuração do Registro A
    HAL_I2C_Mem_Write(hi2c, HMC5883L_ADDRESS, REG_CONFIG_A, 23, &configA, 1, HAL_MAX_DELAY);

    // Configuração do Registro B
    HAL_I2C_Mem_Write(hi2c, HMC5883L_ADDRESS, REG_CONFIG_B, 1, &configB, 1, HAL_MAX_DELAY);

    // Configuração do Modo
    HAL_I2C_Mem_Write(hi2c, HMC5883L_ADDRESS, REG_MODE, 1, &mode, 1, HAL_MAX_DELAY);
}

/******************************************************************************
 * FUNÇÕES DE LEITURA
 *****************************************************************************/

/**
  * @brief  Lê os dados do campo magnético do HMC5883L e os armazena em um array com o sample.
  * @param  hi2c Ponteiro para uma estrutura I2C_HandleTypeDef que contém
  *         as informações de configuração do I2C especificado.
  * @param  reading Array de estruturas XYCoordinates para armazenar os dados brutos do campo magnético.
  * @retval Nenhum
  */
void HMC5883L_ReadData(I2C_HandleTypeDef *hi2c, XYCoordinates reading[8]){
	uint8_t rawData[6];
    for (int i = 0; i < 8; i++) {
        // Lê 6 bytes a partir do registrador REG_DATA_OUT_X_MSB
        HAL_I2C_Mem_Read(hi2c, HMC5883L_ADDRESS, REG_DATA_OUT_X_MSB, 1, rawData, 6, HAL_MAX_DELAY);
        // Converte os dados brutos para inteiros e os armazena
        reading[i].x = (int16_t)((rawData[0] << 8) | rawData[1]);  // X MSB e LSB
        reading[i].y = (int16_t)((rawData[4] << 8) | rawData[5]);  // Y MSB e LSB
    }
}

/******************************************************************************
 * FUNÇÕES DE PROCESSAMENTO DE DADOS
 *****************************************************************************/

/**
  * @brief  Filtra leituras que desviam significativamente do centróide dos dados.
  * @param  reading Array de estruturas XYCoordinates contendo as leituras do campo magnético.
  * @retval O número de leituras válidas restantes após a filtragem.
  */
uint8_t Filter_Data_Mag(XYCoordinates reading[8]){
	const float MIN_DISTANCE = 2;
	XYCoordinates centroid = Data_Means(reading, 8); //Definição do centroide base que será a referencia para a distância minima
	uint8_t resultSize=8;
	for(uint8_t i=0; i<8; i++){
		if(Measure_Distance(reading[i], centroid) > MIN_DISTANCE){
			reading[i].x = 0;
			reading[i].y = 0;
			resultSize--;
		}
	}

	return resultSize;
}

/**
  * @brief  Calcula a distância euclidiana entre dois pontos 2D.
  * @param  a Primeiro ponto (estrutura XYCoordinates).
  * @param  b Segundo ponto (estrutura XYCoordinates).
  * @retval A distância como um valor float.
  */
float Measure_Distance(XYCoordinates a, XYCoordinates b){
	return sqrt(pow((a.x-b.x),2)+pow((a.y-b.y),2));
}

/**
  * @brief  Calcula os valores médios das coordenadas X e Y de um array de leituras.
  * @param  reading Array de estruturas XYCoordinates contendo as leituras do campo magnético.
  * @param  n O número de leituras no array.
  * @retval Uma estrutura XYCoordinates contendo os valores médios de X e Y.
  */
XYCoordinates Data_Means(XYCoordinates reading[8], uint8_t n){
	int16_t meansX = 0;
	int16_t meansY = 0;
	for(uint8_t i=0; i<8; i++){
		meansX += reading[i].x;
		meansY += reading[i].y;
	}
	XYCoordinates coordinateMeans = {meansX/n, meansY/n};
	return coordinateMeans;
}

/******************************************************************************
 * FUNÇÕES DE CÁLCULO DE ÂNGULO
 *****************************************************************************/

/**
  * @brief  Converte coordenadas X e Y em um ângulo em graus tomando em consideração o Norte Magnético da Terra.
  * @param  coordinate Uma estrutura XYCoordinates contendo os valores X e Y.
  * @retval O ângulo em graus, ajustado para um intervalo de 0–360° e corrigido para calibração.
  */
int16_t XY_to_Degrees(XYCoordinates coordinate){

	int16_t angle = atan2(coordinate.y, coordinate.x)*(180.0/M_PI);
	if(angle < 0) angle += 100;
	return (angle - 75); //Calibração de 75° feita por intermedio de comparação com uma bússola no celular

	//return (angle - 75); //Calibração de 75° feita por intermedio de comparação com uma bússola no celular
}

/**
  * @brief  Calcula o ângulo do leme necessário para direcionar em direção ao ângulo de chegada.
  * @param  boatAngle O ângulo atual da embarcação em graus.
  * @param  arrivalAngle O ângulo desejado de chegada em graus.
  * @retval A posição angular do leme a ser aplicado, tomando em consideração a estrutura
  * 		de dados estipulada em leme.c [44[-180°] a 144[180°]].
  */
int16_t RudderDegree(uint16_t boatAngle, int16_t arrivalAngle){
	int16_t rudderAngleShift = boatAngle - arrivalAngle;
	return (int16_t) (-(5.0/18.0)*rudderAngleShift + 62);
}
