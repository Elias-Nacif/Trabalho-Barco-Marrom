/*
 * MOTOReLEME.c
 *
 *  Created on: Nov 23, 2024
 *      Author: Elias Nacif, Vincent, Everson Elias
*/


// ============= INCLUDES ============
#include <rudder1.h>
//#include <stdint.h>
//#include <stdbool.h>

#include "main.h"
#include "pwm.h"
// ===================================


// =========== VARIAVEIS =============
uint16_t currentPosition = 200;
// ==================================


// ============= FUNCOES ============

/**
  * @brief Função de mudança de posicionamento do leme
  * @param1 timer (TIM_HandleTypeDef) : Aponta para o timer usado no leme
  * @param2 channel (uint32_t) : Equivale para o canal de saída do timer
  * @param3 newPosition (uint16_t) : Posição angular nova do leme que varia de 44 (-90°) até 144 (90°)
  *        com ponto neutro sendo 100 (0°)
  * @param4 speed (uint8_t) : Velocidade de giro do Leme [1 a 10]
  * @retval None
  */
void Rudder_Control(TIM_HandleTypeDef timer, uint32_t channel, uint16_t newPosition, uint8_t speed){
	//int i = 0;
//
//	if(newPosition< Min_rudder){
//		currentPosition = Min_rudder;
//	}else if(newPosition>Max_rudder){
//		currentPosition = Max_rudder;
//	}

//	if(newPosition <= currentPosition){
//		for(i=0;i<(currentPosition-newPosition)+1; i+=1){
//			setPWM(timer, channel, 1250, currentPosition-i);
//			HAL_Delay(10);
//		}
//	}
//	else if(newPosition > currentPosition){
//		for(i=0; i<(newPosition-currentPosition)+1; i+=1){
			setPWM(timer, channel, 2500, newPosition);
			HAL_Delay(10);
//		}
//
//	}
//	currentPosition = newPosition;
}


/**
  * @brief Função de Controle do Motor
  * @param1 timer (TIM_HandleTypeDef) : Aponta para o timer usado no leme
  * @param2 channel (uint32_t) : Equivale para o canal de saída do timer
  * @param3 enable (bool) : Ativação ou não do motor
  * @param4 direction (bool) : Aponta para a direção do motor [Adiante ou ré]
  * @param5 speed (uint16_t) : Velocidade de giro do Motor
  * @retval None
  */
