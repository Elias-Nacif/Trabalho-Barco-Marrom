/*
 * @file ble.c
 * @brief Implementação de funções para comunicação BLE usando UART.
 * @details Este arquivo contém funções para inicialização e operação de um módulo BLE, incluindo envio de comandos,
 *          recebimento de dados, processamento de RSSI e cálculo de distâncias.
 * @date Jan 3, 2025
 * @authors Elias Nacif, Everson Elias, Vincent
 */

/*
 * =====================   INCLUDES  =====================
 */

#include "ble.h"
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/*
 * =====================   DEFINITIONS  =====================
 */

#define WINDOW_SIZE 5          // Tamanho da janela deslizante para o filtro de RSSI
#define LIMITE_FILTRO 20       // Limite de variação para filtrar valores de RSSI inconsistentes

/*
 * =====================   VARIABLES   =====================
 */

UART_HandleTypeDef *uart_terminal;

static uint8_t rx_buffer[RX_BUFFER_SIZE]; // Buffer para armazenar dados recebidos via UART
static uint8_t rx_index = 0;              // Índice para rastrear o ponto de gravação no buffer
static uint8_t received_data;             // Armazena o byte mais recente recebido via UART

enum beacons beacons;

// Arrays para armazenar valores de RSSI dos três beacons
static int16_t BeaconsDataRSSI[3] = {0, 0, 0}; // Valores filtrados de RSSI para cada beacon
static int16_t B1_RSSIs[WINDOW_SIZE];         // Janela deslizante para RSSI do beacon 1
static int16_t B2_RSSIs[WINDOW_SIZE];         // Janela deslizante para RSSI do beacon 2
static int16_t B3_RSSIs[WINDOW_SIZE];         // Janela deslizante para RSSI do beacon 3

/*
 * =====================   BLE FUNCTIONS   =====================
 */

/**
 * @brief Inicializa o módulo BLE.
 *
 * Configura o módulo BLE com parâmetros pré-definidos e inicia a recepção de dados UART em modo de interrupção.
 *
 * @param huartBLE Ponteiro para o handle UART configurado para comunicação com o módulo BLE.
 * @param huartTERMINAL Ponteiro para o handle UART configurado para comunicação com o terminal.
 */
void BLE_Init(UART_HandleTypeDef *huartBLE, UART_HandleTypeDef *huartTERMINAL) {
    BLE_Send_Command(huartBLE, CMD_SET_NAME);  // Configura o nome Bluetooth
    BLE_Send_Command(huartBLE, CMD_SET_ROLE);  // Configura o papel do módulo (master/slave)
    BLE_Send_Command(huartBLE, CMD_SET_IAC);   // Configura o código de acesso para descoberta
    BLE_Send_Command(huartBLE, CMD_RESET);     // Reinicia o módulo para aplicar as configurações

    uart_terminal = huartTERMINAL;

    // Inicia a recepção UART no modo interrupção
    HAL_UART_Receive_IT(huartBLE, &received_data, 1);

}

/**
 * @brief Envia um comando para o módulo BLE via UART.
 *
 * @param huartBLE Ponteiro para o handle UART configurado para BLE.
 * @param command String contendo o comando a ser enviado ao módulo BLE.
 */
void BLE_Send_Command(UART_HandleTypeDef *huartBLE, const char *command) {
    if (HAL_UART_Transmit(huartBLE, (uint8_t *)command, strlen(command), UART_TIMEOUT) != HAL_OK) {
        // Caso ocorra um erro na transmissão, é necessário tratá-lo adequadamente.
    }
}

/**
 * @brief Realiza a varredura de dispositivos BLE e processa os dados recebidos.
 *
 * Esta função envia o comando de varredura ao módulo BLE, processa os dados recebidos e atualiza o buffer de recepção.
 *
 * @param huartBLE Ponteiro para o handle UART configurado para comunicação com o módulo BLE.
 */
void BLE_Scan(UART_HandleTypeDef *huartBLE) {
    BLE_Send_Command(huartBLE, CMD_SCAN); // Envia o comando para iniciar a varredura de dispositivos BLE
    HAL_Delay(100);
    if (rx_index > 0) { // Verifica se há dados recebidos no buffer UART

        Parse_Scanned_Data(); // Processa e interpreta os dados recebidos
        memset(rx_buffer, 0, RX_BUFFER_SIZE); // Limpa o buffer de recepção
        rx_index = 0; // Reseta o índice do buffer de recepção

    }
}

/**
 * @brief Callback de recepção UART.
 *
 * Este callback é chamado quando novos dados são recebidos via UART e os armazena no buffer para processamento posterior.
 *
 * @param huart Ponteiro para o handle UART que chamou o callback.
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART3) { // Verifica se a interrupção vem da UART3

        if (rx_index < RX_BUFFER_SIZE - 1) {
            rx_buffer[rx_index++] = received_data; // Armazena o dado recebido no buffer
        }
        // Reativa a recepção UART
        HAL_UART_Receive_IT(huart, &received_data, 1);
    }
}

/*
 * =====================   AUXILIARY FUNCTIONS   =====================
 */

/**
 * @brief Envia texto para o terminal via UART.
 *
 * @param text String contendo os dados a serem enviados.
 */
void Terminal_Send_Text(const char *text) {
    if (HAL_UART_Transmit(uart_terminal, (uint8_t *)text, strlen(text), UART_TIMEOUT) != HAL_OK) {
        // Caso ocorra um erro na transmissão, é necessário tratá-lo adequadamente.
    }
}

/**
 * @brief Processa os dados escaneados recebidos via BLE.
 *
 * Esta função interpreta os dados escaneados que foram recebidos via UART.
 * Ela extrai informações de cada linha que descreve um dispositivo BLE detectado e atualiza
 * os valores de RSSI correspondentes no array BeaconsDataRSSI.
 */
void Parse_Scanned_Data(void) {
    uint8_t buffer[RX_BUFFER_SIZE]; // Buffer auxiliar para preservar os dados originais.
    strcpy((char*)buffer, (char*)rx_buffer); // Copia os dados do buffer de recepção para preservá-lo.
    char *linha;

    // Divide o buffer em linhas separadas por delimitadores de nova linha (\n\r).
    linha = strtok((char *)buffer, "\n\r");

    while (linha != NULL) { // Continua enquanto houver linhas no buffer.
        // Ignora linhas que contenham apenas a string "OK".

        if (strstr(linha, "OK") == NULL) {
            // Verifica se a linha começa com "+DEV:", indicando informações de um dispositivo BLE.
            if (strncmp(linha, "+DEV:", 5) == 0) {
                char dev_id[32];        // Identificador do dispositivo.
                char mac_address[32];  // Endereço MAC do dispositivo.
                int rssi;              // RSSI do dispositivo.
                char device_name[64];  // Nome do dispositivo.

                // Usa sscanf para extrair os campos relevantes da linha.
                if (sscanf(linha, "+DEV:%[^=]=%[^,],%d,%s", dev_id, mac_address, &rssi, device_name) == 4) {
                    // Verifica o nome do dispositivo e atualiza o RSSI no array correspondente.
                    if (strcmp("PSE2022_B1", device_name) == 0) {
                        BeaconsDataRSSI[B1] = Filter_Data(rssi, B1); // Atualiza o RSSI do beacon 1.
                    } else if (strcmp("PSE2022_B2", device_name) == 0) {
                        BeaconsDataRSSI[B2] = Filter_Data(rssi, B2); // Atualiza o RSSI do beacon 2.
                    } else if (strcmp("PSE2022_B3", device_name) == 0) {
                        BeaconsDataRSSI[B3] = Filter_Data(rssi, B3); // Atualiza o RSSI do beacon 3.
                    }
                }
            } else {
                // Caso a linha não seja "+DEV:", envia o conteúdo ao terminal via UART.
                Terminal_Send_Text(linha);
            }
        }

        // Move para a próxima linha no buffer.
        linha = strtok(NULL, "\n\r");
    }
}

/**
 * @brief Exibe os dados de RSSI dos beacons no terminal UART.
 *
 * Esta função formata os dados de RSSI armazenados para os beacons
 * PSE2022_B1, PSE2022_B2 e PSE2022_B3 em strings legíveis e os envia
 * para o terminal UART para fins de monitoramento ou depuração.
 *
 * @param huartTERMINAL Ponteiro para o handle UART configurado para a comunicação com o terminal.
 */
/**
 * @brief Imprime os dados escaneados dos beacons no terminal.
 */
void Print_Scanned_Data(void) {
    // Buffers para armazenar as strings formatadas
    char str1[64], str2[64], str3[64];       // Dados RSSI
    char str1d[64], str2d[64], str3d[64];   // Dados de distância

    // Formata as strings com informações de RSSI e distância
    sprintf(str1, "PSE2022_B1 (RSSI): %d\r\n", BeaconsDataRSSI[B1]);
    sprintf(str1d, "PSE2022_B1 (Distance): %f\r\n", Rssi_to_Distance(BeaconsDataRSSI[B1], B1));

    sprintf(str2, "PSE2022_B2 (RSSI): %d\r\n", BeaconsDataRSSI[B2]);
    sprintf(str2d, "PSE2022_B2 (Distance): %f\r\n", Rssi_to_Distance(BeaconsDataRSSI[B2], B2));

    sprintf(str3, "PSE2022_B3 (RSSI): %d\r\n", BeaconsDataRSSI[B3]);
    sprintf(str3d, "PSE2022_B3 (Distance): %f\r\n", Rssi_to_Distance(BeaconsDataRSSI[B3], B3));

    // Envia os dados formatados via UART
    Terminal_Send_Text(str1);
    Terminal_Send_Text(str1d);

    Terminal_Send_Text(str2);
    Terminal_Send_Text(str2d);

    Terminal_Send_Text(str3);
    Terminal_Send_Text(str3d);
}

/**
 * @brief Filtra o valor de RSSI recebido para evitar dados espúrios.
 *
 * Esta função aplica uma lógica de filtragem para suavizar os valores de RSSI, eliminando variações abruptas que
 * podem ser consideradas ruído. O filtro verifica se a diferença entre o valor mais recente e o anterior excede
 * um limite predefinido. Se exceder, mantém o valor anterior; caso contrário, o novo valor é aceito. Além disso,
 * calcula a média móvel de uma janela de valores armazenados para suavizar o dado.
 *
 * @param newRssi Valor RSSI recém-recebido.
 * @param beacon Índice do beacon correspondente (B1, B2 ou B3).
 * @return O valor filtrado de RSSI.
 */
int16_t Filter_Data(int16_t newRssi, uint8_t beacon) {
    int16_t sum = 0; // Variável para somar os valores da janela de RSSI

    // Atualiza a janela de RSSI com o novo valor recebido
    Update_Window(newRssi, beacon);

    // Realiza a filtragem e cálculo com base no beacon especificado
    switch(beacon) {
        case B1:
            // Filtragem para o beacon B1
            if (abs(B1_RSSIs[0] - B1_RSSIs[1]) > LIMITE_FILTRO) {
                B1_RSSIs[0] = B1_RSSIs[1]; // Mantém o valor anterior se a diferença for muito grande
            }
            // Calcula a média móvel dos valores na janela
            for (int i = 0; i < WINDOW_SIZE; i++) {
                sum += B1_RSSIs[i];
            }
            return sum / WINDOW_SIZE;

        case B2:
            // Filtragem para o beacon B2
            if (abs(B2_RSSIs[0] - B2_RSSIs[1]) > LIMITE_FILTRO) {
                B2_RSSIs[0] = B2_RSSIs[1]; // Mantém o valor anterior se a diferença for muito grande
            }
            // Calcula a média móvel dos valores na janela
            for (int i = 0; i < WINDOW_SIZE; i++) {
                sum += B2_RSSIs[i];
            }
            return sum / WINDOW_SIZE;

        case B3:
            // Filtragem para o beacon B3
            if (abs(B3_RSSIs[0] - B3_RSSIs[1]) > LIMITE_FILTRO) {
                B3_RSSIs[0] = B3_RSSIs[1]; // Mantém o valor anterior se a diferença for muito grande
            }
            // Calcula a média móvel dos valores na janela
            for (int i = 0; i < WINDOW_SIZE; i++) {
                sum += B3_RSSIs[i];
            }
            return sum / WINDOW_SIZE;

        default:
            return 0; // Retorna 0 caso o índice do beacon seja inválido
    }
}

/**
 * @brief Atualiza a janela de valores RSSI para o beacon especificado.
 *
 * Esta função mantém uma janela deslizante de valores RSSI para cada beacon. Se o beacon ainda não possui dados
 * inicializados, a janela é preenchida com o valor atual. Caso contrário, o valor mais antigo é removido e o novo
 * valor é inserido no início da janela, deslocando os demais valores.
 *
 * @param newRssi O novo valor de RSSI recebido.
 * @param beacon O índice do beacon correspondente (B1, B2 ou B3).
 */
void Update_Window(int16_t newRssi, uint8_t beacon) {
    switch (beacon) {
        case B1:
            // Atualização da janela para o beacon B1
            if (!BeaconsDataRSSI[B1]) {
                // Se o beacon não possui dados, inicializa toda a janela com o novo valor
                for (int i = 0; i < WINDOW_SIZE; i++) {
                    B1_RSSIs[i] = newRssi;
                }
            } else {
                // Move os valores para a direita para criar espaço no início
                for (int i = WINDOW_SIZE - 1; i > 0; i--) {
                    B1_RSSIs[i] = B1_RSSIs[i - 1];
                }
                // Insere o novo valor no início da janela
                B1_RSSIs[0] = newRssi;
            }
            break;

        case B2:
            // Atualização da janela para o beacon B2
            if (!BeaconsDataRSSI[B2]) {
                // Se o beacon não possui dados, inicializa toda a janela com o novo valor
                for (int i = 0; i < WINDOW_SIZE; i++) {
                    B2_RSSIs[i] = newRssi;
                }
            } else {
                // Move os valores para a direita para criar espaço no início
                for (int i = WINDOW_SIZE - 1; i > 0; i--) {
                    B2_RSSIs[i] = B2_RSSIs[i - 1];
                }
                // Insere o novo valor no início da janela
                B2_RSSIs[0] = newRssi;
            }
            break;

        case B3:
            // Atualização da janela para o beacon B3
            if (!BeaconsDataRSSI[B3]) {
                // Se o beacon não possui dados, inicializa toda a janela com o novo valor
                for (int i = 0; i < WINDOW_SIZE; i++) {
                    B3_RSSIs[i] = newRssi;
                }
            } else {
                // Move os valores para a direita para criar espaço no início
                for (int i = WINDOW_SIZE - 1; i > 0; i--) {
                    B3_RSSIs[i] = B3_RSSIs[i - 1];
                }
                // Insere o novo valor no início da janela
                B3_RSSIs[0] = newRssi;
            }
            break;

        default:
            // Caso o índice do beacon seja inválido, nenhuma ação é tomada
            break;
    }
}

/**
 * @brief Converte um valor de RSSI em distância estimada.
 *
 * Utiliza uma fórmula logarítmica para calcular a distância aproximada com base no RSSI.
 *
 * @param rssi Valor do RSSI recebido.
 * @param beacon Beacon que está sendo analisado. Cada beacon terá um parâmetro de calibração diferente.
 * @return Distância estimada em metros.
 */
float Rssi_to_Distance(int16_t rssi, uint8_t beacon) {
    float n = 2.3;  // Expoente de perda de propagação para o ambiente
    int16_t txPower[3] = {-64,-54,-59}; // RSSI esperado a 1 metro do beacon em condições ideais {Beacon1, Beacon2, Beacon3}
    return pow(10, (txPower[beacon] - rssi) / (10 * n));
}
