/*
 * MOTOReLEME.h
 *
 *  Created on: Nov 23, 2024
 *      Author: Elias Nacif, Vincent, Everson Elias
 */

#ifndef INC_RUDDER1_H_
#define INC_RUDDER1_H_
#include "main.h"
#define Max_rudder 120
#define Min_rudder 0

#include <stdbool.h>

// ==== VARIAVEIS ====
extern uint16_t currentPosition;
// ===================


// ===== FUNCOES =====

void Rudder_Control(TIM_HandleTypeDef timer, uint32_t channel, uint16_t newPosition, uint8_t speed);

// ===================

#endif /* INC_RUDDER1_H_ */
