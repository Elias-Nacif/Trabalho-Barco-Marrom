/*
 * pwm.h
 *
 *  Created on: Nov 25, 2024
 *      Author: Elias Nacif, Everson Elias, Vincent
 */

#ifndef INC_PWM_H_
#define INC_PWM_H_


// === FUNÇÕES ===
void setPWM(TIM_HandleTypeDef, uint32_t , uint16_t, uint16_t);
void setPWM_motor(TIM_HandleTypeDef, uint32_t , uint16_t, uint16_t);
// ===============


#endif /* INC_PWM_H_ */
