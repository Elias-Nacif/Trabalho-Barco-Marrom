/**
  ******************************************************************************
  * @file           : magnetometro.h
  * @brief          : Biblioteca para interface e manipulação do sensor magnético
  *                   HMC5883L com a placa STM32.
  *
  *                   Este arquivo contém as definições de funções, estruturas e
  *                   protótipos utilizados para configurar, ler dados e processar
  *                   leituras do sensor HMC5883L.
  *
  * @author         : Elias Nacif, Everson Elias, Vincent
  * @date           : 4 de Dezembro de 2024
  * @version        : 2.0
  *
  * @details        : Esta biblioteca foi projetada para uso com o sensor magnético
  *                   HMC5883L, permitindo:
  *                     - Configuração do sensor para modo de operação desejado.
  *                     - Leitura de coordenadas magnéticas X e Y.
  *                     - Processamento de leituras com filtragem e cálculo de ângulos.
  *                     - Cálculo de direção do leme baseado na direção atual e
  *                       ângulo de destino.
  *
  * @hardware       : STM32 Nucleo F446RE
  *                   Sensor HMC5883L
  *
  * @note           : Esta biblioteca depende da HAL (Hardware Abstraction Layer)
  *                   da STMicroelectronics para I2C.
  *
  ******************************************************************************
  */

#ifndef INC_MAGNETOMETRO_H_
#define INC_MAGNETOMETRO_H_
#include "main.h"


typedef struct {
	int16_t x;
	int16_t y;
} XYCoordinates;

void HMC5883L_Init(I2C_HandleTypeDef *hi2c);

void HMC5883L_ReadData(I2C_HandleTypeDef *hi2c, XYCoordinates reading[8]);

uint8_t Filter_Data_Mag(XYCoordinates reading[8]);

float Measure_Distance(XYCoordinates a, XYCoordinates b);

XYCoordinates Data_Means(XYCoordinates reading[8], uint8_t n);

int16_t XY_to_Degrees(XYCoordinates coordinates);

int16_t RudderDegree(uint16_t boatAngle, int16_t arrivalAngle);

#endif /* INC_MAGNETOMETRO_H_ */
