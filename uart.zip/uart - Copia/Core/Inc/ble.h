/*
 * @file ble.h
 * @brief Cabeçalho para funções de comunicação BLE usando UART.
 * @details Este arquivo define os comandos, tipos auxiliares e funções utilizadas na comunicação BLE.
 * @date Jan 3, 2025
 * @authors Elias Nacif, Everson Elias, Vincent
 */

#ifndef INC_BLE_H_
#define INC_BLE_H_

#include "main.h"

/*
 * =====================   COMMAND DEFINITIONS   =====================
 * Definições dos comandos AT usados para configurar e controlar o módulo BLE.
 */
#define CMD_SET_NAME "AT+NAMEbarcomarron\r\n"
#define CMD_SET_ROLE "AT+ROLE1\r\n"
#define CMD_SET_IAC "AT+IAC=0x9E8B33\r\n"
#define CMD_SCAN "AT+INQ\r\n"
#define CMD_RESET "AT+RESET\r\n"
#define RX_BUFFER_SIZE 256
#define UART_TIMEOUT 1000

/*
 * =====================   AUXILIARY TYPES   =====================
 */
enum beacons {
	B1 = 0,
	B2,
	B3
};

/*
 * =====================   BLE FUNCTIONS   =====================
 */
void BLE_Init(UART_HandleTypeDef *huartBLE,UART_HandleTypeDef *huartTERMINAL);
void BLE_Send_Command(UART_HandleTypeDef *huartBLE, const char *command);
void BLE_Scan(UART_HandleTypeDef *huartBLE);
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);


/*
 * =====================   AUXILIARY FUNCTIONS   =====================
 */
void Terminal_Send_Text(const char *text);
void Parse_Scanned_Data(void);
void Print_Scanned_Data(void);
int16_t Filter_Data(int16_t newRssi, uint8_t beacon);
void Update_Window(int16_t newRssi, uint8_t beacon);
float Rssi_to_Distance(int16_t rssi, uint8_t beacon);

#endif /* INC_BLE_H_ */
